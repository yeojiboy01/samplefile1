﻿Public Class LogIn

    Private Sub LogIn_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        
    End Sub

    Private Sub btnLogIn_Click(sender As Object, e As EventArgs) Handles btnLogIn.Click
        If txtUSERNAME.Text = "Pidgey" And txtUSERPASS.Text = "pidgey" Then
            MsgBox("Log  In  Successfully!", MsgBoxStyle.OkOnly, "Log  in Form ")
            Me.Hide()
            MainMenu.Show()
        Else
            MsgBox("Login  unsuccessful  please  try  again.",MsgBoxStyle.OkOnly,  "Invalid") 
        End If
    End Sub
End Class