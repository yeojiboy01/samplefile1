﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim StateProperties3 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainMenu))
        Dim StateProperties1 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties()
        Dim StateProperties2 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties()
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.BunifuLabel1 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BunifuPictureBox3 = New Bunifu.UI.WinForms.BunifuPictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblCheesyBurgerDeluxe = New System.Windows.Forms.TextBox()
        Me.lblGarlicShrimp = New System.Windows.Forms.TextBox()
        Me.lblHawaiian = New System.Windows.Forms.TextBox()
        Me.lblPepperoni = New System.Windows.Forms.TextBox()
        Me.lblMargherita = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtbxCheesyBurgerDeluxe = New System.Windows.Forms.TextBox()
        Me.txtbxGarlicShrimp = New System.Windows.Forms.TextBox()
        Me.txtbxHawaiian = New System.Windows.Forms.TextBox()
        Me.txtbxPepperoni = New System.Windows.Forms.TextBox()
        Me.txtbxMargherita = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.chckbxGarlicShrimp = New System.Windows.Forms.CheckBox()
        Me.chckbxHawaiian = New System.Windows.Forms.CheckBox()
        Me.chckbxPepperoni = New System.Windows.Forms.CheckBox()
        Me.chckbxMargherita = New System.Windows.Forms.CheckBox()
        Me.chckbxCheesyBurgerDeluxe = New System.Windows.Forms.CheckBox()
        Me.BunifuPictureBox1 = New Bunifu.UI.WinForms.BunifuPictureBox()
        Me.lblS5 = New System.Windows.Forms.Label()
        Me.lblS4 = New System.Windows.Forms.Label()
        Me.lblS3 = New System.Windows.Forms.Label()
        Me.lblS2 = New System.Windows.Forms.Label()
        Me.lblS1 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblBolognese = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblAlle = New System.Windows.Forms.TextBox()
        Me.txtbxBolognese = New System.Windows.Forms.TextBox()
        Me.lblAglio = New System.Windows.Forms.TextBox()
        Me.txtbxAlleVongole = New System.Windows.Forms.TextBox()
        Me.lblCarbonara = New System.Windows.Forms.TextBox()
        Me.txtbxAglioOlio = New System.Windows.Forms.TextBox()
        Me.lblTomato = New System.Windows.Forms.TextBox()
        Me.txtbxCarbonara = New System.Windows.Forms.TextBox()
        Me.txtbxTomato = New System.Windows.Forms.TextBox()
        Me.chckbxBolognese = New System.Windows.Forms.CheckBox()
        Me.chckbxAlleVongole = New System.Windows.Forms.CheckBox()
        Me.chckbxAglioOlio = New System.Windows.Forms.CheckBox()
        Me.chckbxCarbonara = New System.Windows.Forms.CheckBox()
        Me.chckbxTomato = New System.Windows.Forms.CheckBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.BunifuPictureBox2 = New Bunifu.UI.WinForms.BunifuPictureBox()
        Me.lblS10 = New System.Windows.Forms.Label()
        Me.lblS9 = New System.Windows.Forms.Label()
        Me.lblS7 = New System.Windows.Forms.Label()
        Me.lblS6 = New System.Windows.Forms.Label()
        Me.lblS8 = New System.Windows.Forms.Label()
        Me.txtbxSubTotal = New System.Windows.Forms.TextBox()
        Me.txtbxTax = New System.Windows.Forms.TextBox()
        Me.txtbxChange = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtbxTotal = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtbxPayment = New System.Windows.Forms.TextBox()
        Me.cmbPayment = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.btnPay = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New Bunifu.UI.WinForms.BunifuDataGridView()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Delete = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.BunifuPictureBox4 = New Bunifu.UI.WinForms.BunifuPictureBox()
        Me.btnExit = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.btnCalculate = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.Quantity = New System.Windows.Forms.TextBox()
        Me.product = New System.Windows.Forms.TextBox()
        Me.Panel1.SuspendLayout()
        CType(Me.BunifuPictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.BunifuPictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.BunifuPictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel6.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BunifuPictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 5
        Me.BunifuElipse1.TargetControl = Me
        '
        'BunifuLabel1
        '
        Me.BunifuLabel1.AutoEllipsis = False
        Me.BunifuLabel1.CursorType = Nothing
        Me.BunifuLabel1.Font = New System.Drawing.Font("Comic Sans MS", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel1.ForeColor = System.Drawing.Color.White
        Me.BunifuLabel1.Location = New System.Drawing.Point(363, 12)
        Me.BunifuLabel1.Name = "BunifuLabel1"
        Me.BunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel1.Size = New System.Drawing.Size(381, 47)
        Me.BunifuLabel1.TabIndex = 0
        Me.BunifuLabel1.Text = "Pidgey's Ordering Sytem"
        Me.BunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Crimson
        Me.Panel1.Controls.Add(Me.BunifuPictureBox3)
        Me.Panel1.Controls.Add(Me.BunifuLabel1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1068, 67)
        Me.Panel1.TabIndex = 1
        '
        'BunifuPictureBox3
        '
        Me.BunifuPictureBox3.AllowFocused = False
        Me.BunifuPictureBox3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.BunifuPictureBox3.BorderRadius = 48
        Me.BunifuPictureBox3.Image = Global.RestaurantOrderingSystem.My.Resources.Resources._240498
        Me.BunifuPictureBox3.IsCircle = True
        Me.BunifuPictureBox3.Location = New System.Drawing.Point(242, -15)
        Me.BunifuPictureBox3.Name = "BunifuPictureBox3"
        Me.BunifuPictureBox3.Size = New System.Drawing.Size(96, 96)
        Me.BunifuPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.BunifuPictureBox3.TabIndex = 35
        Me.BunifuPictureBox3.TabStop = False
        Me.BunifuPictureBox3.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.lblCheesyBurgerDeluxe)
        Me.Panel2.Controls.Add(Me.lblGarlicShrimp)
        Me.Panel2.Controls.Add(Me.lblHawaiian)
        Me.Panel2.Controls.Add(Me.lblPepperoni)
        Me.Panel2.Controls.Add(Me.lblMargherita)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.txtbxCheesyBurgerDeluxe)
        Me.Panel2.Controls.Add(Me.txtbxGarlicShrimp)
        Me.Panel2.Controls.Add(Me.txtbxHawaiian)
        Me.Panel2.Controls.Add(Me.txtbxPepperoni)
        Me.Panel2.Controls.Add(Me.txtbxMargherita)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.chckbxGarlicShrimp)
        Me.Panel2.Controls.Add(Me.chckbxHawaiian)
        Me.Panel2.Controls.Add(Me.chckbxPepperoni)
        Me.Panel2.Controls.Add(Me.chckbxMargherita)
        Me.Panel2.Controls.Add(Me.chckbxCheesyBurgerDeluxe)
        Me.Panel2.Controls.Add(Me.BunifuPictureBox1)
        Me.Panel2.Controls.Add(Me.lblS5)
        Me.Panel2.Controls.Add(Me.lblS4)
        Me.Panel2.Controls.Add(Me.lblS3)
        Me.Panel2.Controls.Add(Me.lblS2)
        Me.Panel2.Controls.Add(Me.lblS1)
        Me.Panel2.Location = New System.Drawing.Point(28, 92)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(380, 404)
        Me.Panel2.TabIndex = 2
        '
        'lblCheesyBurgerDeluxe
        '
        Me.lblCheesyBurgerDeluxe.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblCheesyBurgerDeluxe.Enabled = False
        Me.lblCheesyBurgerDeluxe.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCheesyBurgerDeluxe.ForeColor = System.Drawing.Color.Black
        Me.lblCheesyBurgerDeluxe.Location = New System.Drawing.Point(190, 367)
        Me.lblCheesyBurgerDeluxe.MaxLength = 2
        Me.lblCheesyBurgerDeluxe.Name = "lblCheesyBurgerDeluxe"
        Me.lblCheesyBurgerDeluxe.ReadOnly = True
        Me.lblCheesyBurgerDeluxe.Size = New System.Drawing.Size(67, 19)
        Me.lblCheesyBurgerDeluxe.TabIndex = 44
        Me.lblCheesyBurgerDeluxe.Text = "25"
        Me.lblCheesyBurgerDeluxe.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblGarlicShrimp
        '
        Me.lblGarlicShrimp.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblGarlicShrimp.Enabled = False
        Me.lblGarlicShrimp.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGarlicShrimp.ForeColor = System.Drawing.Color.Black
        Me.lblGarlicShrimp.Location = New System.Drawing.Point(190, 335)
        Me.lblGarlicShrimp.MaxLength = 2
        Me.lblGarlicShrimp.Name = "lblGarlicShrimp"
        Me.lblGarlicShrimp.ReadOnly = True
        Me.lblGarlicShrimp.Size = New System.Drawing.Size(67, 19)
        Me.lblGarlicShrimp.TabIndex = 43
        Me.lblGarlicShrimp.Text = "25"
        Me.lblGarlicShrimp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblHawaiian
        '
        Me.lblHawaiian.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblHawaiian.Enabled = False
        Me.lblHawaiian.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHawaiian.ForeColor = System.Drawing.Color.Black
        Me.lblHawaiian.Location = New System.Drawing.Point(190, 301)
        Me.lblHawaiian.MaxLength = 2
        Me.lblHawaiian.Name = "lblHawaiian"
        Me.lblHawaiian.ReadOnly = True
        Me.lblHawaiian.Size = New System.Drawing.Size(67, 19)
        Me.lblHawaiian.TabIndex = 42
        Me.lblHawaiian.Text = "25"
        Me.lblHawaiian.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblPepperoni
        '
        Me.lblPepperoni.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblPepperoni.Enabled = False
        Me.lblPepperoni.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPepperoni.ForeColor = System.Drawing.Color.Black
        Me.lblPepperoni.Location = New System.Drawing.Point(190, 270)
        Me.lblPepperoni.MaxLength = 2
        Me.lblPepperoni.Name = "lblPepperoni"
        Me.lblPepperoni.ReadOnly = True
        Me.lblPepperoni.Size = New System.Drawing.Size(67, 19)
        Me.lblPepperoni.TabIndex = 41
        Me.lblPepperoni.Text = "25"
        Me.lblPepperoni.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblMargherita
        '
        Me.lblMargherita.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblMargherita.Enabled = False
        Me.lblMargherita.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMargherita.ForeColor = System.Drawing.Color.Black
        Me.lblMargherita.Location = New System.Drawing.Point(190, 240)
        Me.lblMargherita.MaxLength = 2
        Me.lblMargherita.Name = "lblMargherita"
        Me.lblMargherita.ReadOnly = True
        Me.lblMargherita.Size = New System.Drawing.Size(67, 19)
        Me.lblMargherita.TabIndex = 40
        Me.lblMargherita.Text = "25"
        Me.lblMargherita.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Candara", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(304, 209)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(63, 18)
        Me.Label12.TabIndex = 39
        Me.Label12.Text = "Quantity"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Candara", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(198, 211)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(48, 18)
        Me.Label11.TabIndex = 38
        Me.Label11.Text = "Stocks"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Candara", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(19, 211)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 18)
        Me.Label5.TabIndex = 37
        Me.Label5.Text = "Pizza"
        '
        'txtbxCheesyBurgerDeluxe
        '
        Me.txtbxCheesyBurgerDeluxe.Enabled = False
        Me.txtbxCheesyBurgerDeluxe.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbxCheesyBurgerDeluxe.ForeColor = System.Drawing.Color.Black
        Me.txtbxCheesyBurgerDeluxe.Location = New System.Drawing.Point(302, 367)
        Me.txtbxCheesyBurgerDeluxe.MaxLength = 2
        Me.txtbxCheesyBurgerDeluxe.Name = "txtbxCheesyBurgerDeluxe"
        Me.txtbxCheesyBurgerDeluxe.Size = New System.Drawing.Size(67, 22)
        Me.txtbxCheesyBurgerDeluxe.TabIndex = 14
        Me.txtbxCheesyBurgerDeluxe.Text = "0"
        Me.txtbxCheesyBurgerDeluxe.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtbxGarlicShrimp
        '
        Me.txtbxGarlicShrimp.Enabled = False
        Me.txtbxGarlicShrimp.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbxGarlicShrimp.ForeColor = System.Drawing.Color.Black
        Me.txtbxGarlicShrimp.Location = New System.Drawing.Point(302, 333)
        Me.txtbxGarlicShrimp.MaxLength = 2
        Me.txtbxGarlicShrimp.Name = "txtbxGarlicShrimp"
        Me.txtbxGarlicShrimp.Size = New System.Drawing.Size(67, 22)
        Me.txtbxGarlicShrimp.TabIndex = 13
        Me.txtbxGarlicShrimp.Text = "0"
        Me.txtbxGarlicShrimp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtbxHawaiian
        '
        Me.txtbxHawaiian.Enabled = False
        Me.txtbxHawaiian.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbxHawaiian.ForeColor = System.Drawing.Color.Black
        Me.txtbxHawaiian.Location = New System.Drawing.Point(302, 301)
        Me.txtbxHawaiian.MaxLength = 2
        Me.txtbxHawaiian.Name = "txtbxHawaiian"
        Me.txtbxHawaiian.Size = New System.Drawing.Size(67, 22)
        Me.txtbxHawaiian.TabIndex = 12
        Me.txtbxHawaiian.Text = "0"
        Me.txtbxHawaiian.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtbxPepperoni
        '
        Me.txtbxPepperoni.Enabled = False
        Me.txtbxPepperoni.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbxPepperoni.ForeColor = System.Drawing.Color.Black
        Me.txtbxPepperoni.Location = New System.Drawing.Point(302, 269)
        Me.txtbxPepperoni.MaxLength = 2
        Me.txtbxPepperoni.Name = "txtbxPepperoni"
        Me.txtbxPepperoni.Size = New System.Drawing.Size(67, 22)
        Me.txtbxPepperoni.TabIndex = 11
        Me.txtbxPepperoni.Text = "0"
        Me.txtbxPepperoni.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtbxMargherita
        '
        Me.txtbxMargherita.Enabled = False
        Me.txtbxMargherita.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbxMargherita.ForeColor = System.Drawing.Color.Black
        Me.txtbxMargherita.Location = New System.Drawing.Point(302, 240)
        Me.txtbxMargherita.MaxLength = 2
        Me.txtbxMargherita.Name = "txtbxMargherita"
        Me.txtbxMargherita.Size = New System.Drawing.Size(67, 22)
        Me.txtbxMargherita.TabIndex = 10
        Me.txtbxMargherita.Text = "0"
        Me.txtbxMargherita.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Candara", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(151, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 18)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "18'' Pizzeria"
        '
        'chckbxGarlicShrimp
        '
        Me.chckbxGarlicShrimp.AutoSize = True
        Me.chckbxGarlicShrimp.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chckbxGarlicShrimp.Location = New System.Drawing.Point(22, 332)
        Me.chckbxGarlicShrimp.Name = "chckbxGarlicShrimp"
        Me.chckbxGarlicShrimp.Size = New System.Drawing.Size(132, 21)
        Me.chckbxGarlicShrimp.TabIndex = 3
        Me.chckbxGarlicShrimp.Text = "Garlic and Shrimp"
        Me.chckbxGarlicShrimp.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chckbxGarlicShrimp.UseVisualStyleBackColor = True
        '
        'chckbxHawaiian
        '
        Me.chckbxHawaiian.AutoSize = True
        Me.chckbxHawaiian.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chckbxHawaiian.Location = New System.Drawing.Point(22, 300)
        Me.chckbxHawaiian.Name = "chckbxHawaiian"
        Me.chckbxHawaiian.Size = New System.Drawing.Size(82, 21)
        Me.chckbxHawaiian.TabIndex = 2
        Me.chckbxHawaiian.Text = "Hawaiian"
        Me.chckbxHawaiian.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chckbxHawaiian.UseVisualStyleBackColor = True
        '
        'chckbxPepperoni
        '
        Me.chckbxPepperoni.AutoSize = True
        Me.chckbxPepperoni.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chckbxPepperoni.Location = New System.Drawing.Point(22, 268)
        Me.chckbxPepperoni.Name = "chckbxPepperoni"
        Me.chckbxPepperoni.Size = New System.Drawing.Size(88, 21)
        Me.chckbxPepperoni.TabIndex = 1
        Me.chckbxPepperoni.Text = "Pepperoni"
        Me.chckbxPepperoni.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chckbxPepperoni.UseVisualStyleBackColor = True
        '
        'chckbxMargherita
        '
        Me.chckbxMargherita.AutoSize = True
        Me.chckbxMargherita.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chckbxMargherita.Location = New System.Drawing.Point(22, 239)
        Me.chckbxMargherita.Name = "chckbxMargherita"
        Me.chckbxMargherita.Size = New System.Drawing.Size(93, 21)
        Me.chckbxMargherita.TabIndex = 0
        Me.chckbxMargherita.Text = "Margherita"
        Me.chckbxMargherita.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chckbxMargherita.UseVisualStyleBackColor = True
        '
        'chckbxCheesyBurgerDeluxe
        '
        Me.chckbxCheesyBurgerDeluxe.AutoSize = True
        Me.chckbxCheesyBurgerDeluxe.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chckbxCheesyBurgerDeluxe.Location = New System.Drawing.Point(22, 365)
        Me.chckbxCheesyBurgerDeluxe.Name = "chckbxCheesyBurgerDeluxe"
        Me.chckbxCheesyBurgerDeluxe.Size = New System.Drawing.Size(155, 21)
        Me.chckbxCheesyBurgerDeluxe.TabIndex = 4
        Me.chckbxCheesyBurgerDeluxe.Text = "Cheesy Burger Deluxe"
        Me.chckbxCheesyBurgerDeluxe.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chckbxCheesyBurgerDeluxe.UseVisualStyleBackColor = True
        '
        'BunifuPictureBox1
        '
        Me.BunifuPictureBox1.AllowFocused = False
        Me.BunifuPictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.BunifuPictureBox1.BorderRadius = 50
        Me.BunifuPictureBox1.Image = Global.RestaurantOrderingSystem.My.Resources.Resources.hot_and_spicy
        Me.BunifuPictureBox1.IsCircle = True
        Me.BunifuPictureBox1.Location = New System.Drawing.Point(84, 18)
        Me.BunifuPictureBox1.Name = "BunifuPictureBox1"
        Me.BunifuPictureBox1.Size = New System.Drawing.Size(216, 216)
        Me.BunifuPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.BunifuPictureBox1.TabIndex = 15
        Me.BunifuPictureBox1.TabStop = False
        Me.BunifuPictureBox1.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square
        '
        'lblS5
        '
        Me.lblS5.AutoSize = True
        Me.lblS5.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblS5.ForeColor = System.Drawing.Color.Black
        Me.lblS5.Location = New System.Drawing.Point(187, 367)
        Me.lblS5.Name = "lblS5"
        Me.lblS5.Size = New System.Drawing.Size(74, 16)
        Me.lblS5.TabIndex = 55
        Me.lblS5.Text = "Out of Stock"
        '
        'lblS4
        '
        Me.lblS4.AutoSize = True
        Me.lblS4.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblS4.ForeColor = System.Drawing.Color.Black
        Me.lblS4.Location = New System.Drawing.Point(187, 335)
        Me.lblS4.Name = "lblS4"
        Me.lblS4.Size = New System.Drawing.Size(74, 16)
        Me.lblS4.TabIndex = 54
        Me.lblS4.Text = "Out of Stock"
        '
        'lblS3
        '
        Me.lblS3.AutoSize = True
        Me.lblS3.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblS3.ForeColor = System.Drawing.Color.Black
        Me.lblS3.Location = New System.Drawing.Point(187, 302)
        Me.lblS3.Name = "lblS3"
        Me.lblS3.Size = New System.Drawing.Size(74, 16)
        Me.lblS3.TabIndex = 53
        Me.lblS3.Text = "Out of Stock"
        '
        'lblS2
        '
        Me.lblS2.AutoSize = True
        Me.lblS2.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblS2.ForeColor = System.Drawing.Color.Black
        Me.lblS2.Location = New System.Drawing.Point(187, 270)
        Me.lblS2.Name = "lblS2"
        Me.lblS2.Size = New System.Drawing.Size(74, 16)
        Me.lblS2.TabIndex = 52
        Me.lblS2.Text = "Out of Stock"
        '
        'lblS1
        '
        Me.lblS1.AutoSize = True
        Me.lblS1.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblS1.ForeColor = System.Drawing.Color.Black
        Me.lblS1.Location = New System.Drawing.Point(187, 240)
        Me.lblS1.Name = "lblS1"
        Me.lblS1.Size = New System.Drawing.Size(74, 16)
        Me.lblS1.TabIndex = 51
        Me.lblS1.Text = "Out of Stock"
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.Label13)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Controls.Add(Me.lblBolognese)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.lblAlle)
        Me.Panel3.Controls.Add(Me.txtbxBolognese)
        Me.Panel3.Controls.Add(Me.lblAglio)
        Me.Panel3.Controls.Add(Me.txtbxAlleVongole)
        Me.Panel3.Controls.Add(Me.lblCarbonara)
        Me.Panel3.Controls.Add(Me.txtbxAglioOlio)
        Me.Panel3.Controls.Add(Me.lblTomato)
        Me.Panel3.Controls.Add(Me.txtbxCarbonara)
        Me.Panel3.Controls.Add(Me.txtbxTomato)
        Me.Panel3.Controls.Add(Me.chckbxBolognese)
        Me.Panel3.Controls.Add(Me.chckbxAlleVongole)
        Me.Panel3.Controls.Add(Me.chckbxAglioOlio)
        Me.Panel3.Controls.Add(Me.chckbxCarbonara)
        Me.Panel3.Controls.Add(Me.chckbxTomato)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Controls.Add(Me.BunifuPictureBox2)
        Me.Panel3.Controls.Add(Me.lblS10)
        Me.Panel3.Controls.Add(Me.lblS9)
        Me.Panel3.Controls.Add(Me.lblS7)
        Me.Panel3.Controls.Add(Me.lblS6)
        Me.Panel3.Controls.Add(Me.lblS8)
        Me.Panel3.Location = New System.Drawing.Point(418, 92)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(380, 404)
        Me.Panel3.TabIndex = 3
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Candara", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(27, 209)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(43, 18)
        Me.Label13.TabIndex = 45
        Me.Label13.Text = "Pasta"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Candara", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(201, 211)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 18)
        Me.Label3.TabIndex = 45
        Me.Label3.Text = "Stocks"
        '
        'lblBolognese
        '
        Me.lblBolognese.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblBolognese.Enabled = False
        Me.lblBolognese.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBolognese.ForeColor = System.Drawing.Color.Black
        Me.lblBolognese.Location = New System.Drawing.Point(191, 367)
        Me.lblBolognese.MaxLength = 2
        Me.lblBolognese.Name = "lblBolognese"
        Me.lblBolognese.ReadOnly = True
        Me.lblBolognese.Size = New System.Drawing.Size(67, 19)
        Me.lblBolognese.TabIndex = 49
        Me.lblBolognese.Text = "25"
        Me.lblBolognese.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Candara", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(306, 211)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 18)
        Me.Label2.TabIndex = 40
        Me.Label2.Text = "Quantity"
        '
        'lblAlle
        '
        Me.lblAlle.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblAlle.Enabled = False
        Me.lblAlle.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAlle.ForeColor = System.Drawing.Color.Black
        Me.lblAlle.Location = New System.Drawing.Point(191, 335)
        Me.lblAlle.MaxLength = 2
        Me.lblAlle.Name = "lblAlle"
        Me.lblAlle.ReadOnly = True
        Me.lblAlle.Size = New System.Drawing.Size(67, 19)
        Me.lblAlle.TabIndex = 48
        Me.lblAlle.Text = "25"
        Me.lblAlle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtbxBolognese
        '
        Me.txtbxBolognese.Enabled = False
        Me.txtbxBolognese.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbxBolognese.ForeColor = System.Drawing.Color.Black
        Me.txtbxBolognese.Location = New System.Drawing.Point(303, 370)
        Me.txtbxBolognese.MaxLength = 2
        Me.txtbxBolognese.Name = "txtbxBolognese"
        Me.txtbxBolognese.Size = New System.Drawing.Size(67, 22)
        Me.txtbxBolognese.TabIndex = 30
        Me.txtbxBolognese.Text = "0"
        Me.txtbxBolognese.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblAglio
        '
        Me.lblAglio.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblAglio.Enabled = False
        Me.lblAglio.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAglio.ForeColor = System.Drawing.Color.Black
        Me.lblAglio.Location = New System.Drawing.Point(191, 301)
        Me.lblAglio.MaxLength = 2
        Me.lblAglio.Name = "lblAglio"
        Me.lblAglio.ReadOnly = True
        Me.lblAglio.Size = New System.Drawing.Size(67, 19)
        Me.lblAglio.TabIndex = 47
        Me.lblAglio.Text = "25"
        Me.lblAglio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtbxAlleVongole
        '
        Me.txtbxAlleVongole.Enabled = False
        Me.txtbxAlleVongole.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbxAlleVongole.ForeColor = System.Drawing.Color.Black
        Me.txtbxAlleVongole.Location = New System.Drawing.Point(303, 337)
        Me.txtbxAlleVongole.MaxLength = 2
        Me.txtbxAlleVongole.Name = "txtbxAlleVongole"
        Me.txtbxAlleVongole.Size = New System.Drawing.Size(67, 22)
        Me.txtbxAlleVongole.TabIndex = 29
        Me.txtbxAlleVongole.Text = "0"
        Me.txtbxAlleVongole.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblCarbonara
        '
        Me.lblCarbonara.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblCarbonara.Enabled = False
        Me.lblCarbonara.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCarbonara.ForeColor = System.Drawing.Color.Black
        Me.lblCarbonara.Location = New System.Drawing.Point(191, 270)
        Me.lblCarbonara.MaxLength = 2
        Me.lblCarbonara.Name = "lblCarbonara"
        Me.lblCarbonara.ReadOnly = True
        Me.lblCarbonara.Size = New System.Drawing.Size(67, 19)
        Me.lblCarbonara.TabIndex = 46
        Me.lblCarbonara.Text = "25"
        Me.lblCarbonara.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtbxAglioOlio
        '
        Me.txtbxAglioOlio.Enabled = False
        Me.txtbxAglioOlio.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbxAglioOlio.ForeColor = System.Drawing.Color.Black
        Me.txtbxAglioOlio.Location = New System.Drawing.Point(303, 304)
        Me.txtbxAglioOlio.MaxLength = 2
        Me.txtbxAglioOlio.Name = "txtbxAglioOlio"
        Me.txtbxAglioOlio.Size = New System.Drawing.Size(67, 22)
        Me.txtbxAglioOlio.TabIndex = 28
        Me.txtbxAglioOlio.Text = "0"
        Me.txtbxAglioOlio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblTomato
        '
        Me.lblTomato.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblTomato.Enabled = False
        Me.lblTomato.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTomato.ForeColor = System.Drawing.Color.Black
        Me.lblTomato.Location = New System.Drawing.Point(191, 240)
        Me.lblTomato.MaxLength = 2
        Me.lblTomato.Name = "lblTomato"
        Me.lblTomato.ReadOnly = True
        Me.lblTomato.Size = New System.Drawing.Size(67, 19)
        Me.lblTomato.TabIndex = 45
        Me.lblTomato.Text = "25"
        Me.lblTomato.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtbxCarbonara
        '
        Me.txtbxCarbonara.Enabled = False
        Me.txtbxCarbonara.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbxCarbonara.ForeColor = System.Drawing.Color.Black
        Me.txtbxCarbonara.Location = New System.Drawing.Point(303, 270)
        Me.txtbxCarbonara.MaxLength = 2
        Me.txtbxCarbonara.Name = "txtbxCarbonara"
        Me.txtbxCarbonara.Size = New System.Drawing.Size(67, 22)
        Me.txtbxCarbonara.TabIndex = 27
        Me.txtbxCarbonara.Text = "0"
        Me.txtbxCarbonara.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtbxTomato
        '
        Me.txtbxTomato.Enabled = False
        Me.txtbxTomato.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbxTomato.ForeColor = System.Drawing.Color.Black
        Me.txtbxTomato.Location = New System.Drawing.Point(303, 237)
        Me.txtbxTomato.MaxLength = 2
        Me.txtbxTomato.Name = "txtbxTomato"
        Me.txtbxTomato.Size = New System.Drawing.Size(67, 22)
        Me.txtbxTomato.TabIndex = 26
        Me.txtbxTomato.Text = "0"
        Me.txtbxTomato.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chckbxBolognese
        '
        Me.chckbxBolognese.AutoSize = True
        Me.chckbxBolognese.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chckbxBolognese.Location = New System.Drawing.Point(30, 370)
        Me.chckbxBolognese.Name = "chckbxBolognese"
        Me.chckbxBolognese.Size = New System.Drawing.Size(89, 21)
        Me.chckbxBolognese.TabIndex = 20
        Me.chckbxBolognese.Text = "Bolognese"
        Me.chckbxBolognese.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chckbxBolognese.UseVisualStyleBackColor = True
        '
        'chckbxAlleVongole
        '
        Me.chckbxAlleVongole.AutoSize = True
        Me.chckbxAlleVongole.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chckbxAlleVongole.Location = New System.Drawing.Point(30, 337)
        Me.chckbxAlleVongole.Name = "chckbxAlleVongole"
        Me.chckbxAlleVongole.Size = New System.Drawing.Size(104, 21)
        Me.chckbxAlleVongole.TabIndex = 19
        Me.chckbxAlleVongole.Text = "Alle Vongole"
        Me.chckbxAlleVongole.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chckbxAlleVongole.UseVisualStyleBackColor = True
        '
        'chckbxAglioOlio
        '
        Me.chckbxAglioOlio.AutoSize = True
        Me.chckbxAglioOlio.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chckbxAglioOlio.Location = New System.Drawing.Point(30, 302)
        Me.chckbxAglioOlio.Name = "chckbxAglioOlio"
        Me.chckbxAglioOlio.Size = New System.Drawing.Size(85, 21)
        Me.chckbxAglioOlio.TabIndex = 18
        Me.chckbxAglioOlio.Text = "Aglio Olio"
        Me.chckbxAglioOlio.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chckbxAglioOlio.UseVisualStyleBackColor = True
        '
        'chckbxCarbonara
        '
        Me.chckbxCarbonara.AutoSize = True
        Me.chckbxCarbonara.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chckbxCarbonara.Location = New System.Drawing.Point(30, 268)
        Me.chckbxCarbonara.Name = "chckbxCarbonara"
        Me.chckbxCarbonara.Size = New System.Drawing.Size(91, 21)
        Me.chckbxCarbonara.TabIndex = 17
        Me.chckbxCarbonara.Text = "Carbonara"
        Me.chckbxCarbonara.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chckbxCarbonara.UseVisualStyleBackColor = True
        '
        'chckbxTomato
        '
        Me.chckbxTomato.AutoSize = True
        Me.chckbxTomato.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chckbxTomato.Location = New System.Drawing.Point(30, 237)
        Me.chckbxTomato.Name = "chckbxTomato"
        Me.chckbxTomato.Size = New System.Drawing.Size(108, 21)
        Me.chckbxTomato.TabIndex = 16
        Me.chckbxTomato.Text = "Tomato Pasta"
        Me.chckbxTomato.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chckbxTomato.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Candara", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(165, 10)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 18)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Pasteria"
        '
        'BunifuPictureBox2
        '
        Me.BunifuPictureBox2.AllowFocused = False
        Me.BunifuPictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.BunifuPictureBox2.BorderRadius = 50
        Me.BunifuPictureBox2.Image = Global.RestaurantOrderingSystem.My.Resources.Resources.mix_sauce_pasta
        Me.BunifuPictureBox2.IsCircle = True
        Me.BunifuPictureBox2.Location = New System.Drawing.Point(60, 0)
        Me.BunifuPictureBox2.Name = "BunifuPictureBox2"
        Me.BunifuPictureBox2.Size = New System.Drawing.Size(250, 250)
        Me.BunifuPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.BunifuPictureBox2.TabIndex = 31
        Me.BunifuPictureBox2.TabStop = False
        Me.BunifuPictureBox2.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square
        '
        'lblS10
        '
        Me.lblS10.AutoSize = True
        Me.lblS10.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblS10.ForeColor = System.Drawing.Color.Black
        Me.lblS10.Location = New System.Drawing.Point(188, 369)
        Me.lblS10.Name = "lblS10"
        Me.lblS10.Size = New System.Drawing.Size(74, 16)
        Me.lblS10.TabIndex = 35
        Me.lblS10.Text = "Out of Stock"
        '
        'lblS9
        '
        Me.lblS9.AutoSize = True
        Me.lblS9.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblS9.ForeColor = System.Drawing.Color.Black
        Me.lblS9.Location = New System.Drawing.Point(188, 337)
        Me.lblS9.Name = "lblS9"
        Me.lblS9.Size = New System.Drawing.Size(74, 16)
        Me.lblS9.TabIndex = 50
        Me.lblS9.Text = "Out of Stock"
        '
        'lblS7
        '
        Me.lblS7.AutoSize = True
        Me.lblS7.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblS7.ForeColor = System.Drawing.Color.Black
        Me.lblS7.Location = New System.Drawing.Point(188, 270)
        Me.lblS7.Name = "lblS7"
        Me.lblS7.Size = New System.Drawing.Size(74, 16)
        Me.lblS7.TabIndex = 53
        Me.lblS7.Text = "Out of Stock"
        '
        'lblS6
        '
        Me.lblS6.AutoSize = True
        Me.lblS6.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblS6.ForeColor = System.Drawing.Color.Black
        Me.lblS6.Location = New System.Drawing.Point(188, 240)
        Me.lblS6.Name = "lblS6"
        Me.lblS6.Size = New System.Drawing.Size(74, 16)
        Me.lblS6.TabIndex = 52
        Me.lblS6.Text = "Out of Stock"
        '
        'lblS8
        '
        Me.lblS8.AutoSize = True
        Me.lblS8.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblS8.ForeColor = System.Drawing.Color.Black
        Me.lblS8.Location = New System.Drawing.Point(188, 301)
        Me.lblS8.Name = "lblS8"
        Me.lblS8.Size = New System.Drawing.Size(74, 16)
        Me.lblS8.TabIndex = 51
        Me.lblS8.Text = "Out of Stock"
        '
        'txtbxSubTotal
        '
        Me.txtbxSubTotal.Enabled = False
        Me.txtbxSubTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbxSubTotal.ForeColor = System.Drawing.Color.Black
        Me.txtbxSubTotal.Location = New System.Drawing.Point(103, 253)
        Me.txtbxSubTotal.Name = "txtbxSubTotal"
        Me.txtbxSubTotal.Size = New System.Drawing.Size(96, 22)
        Me.txtbxSubTotal.TabIndex = 30
        Me.txtbxSubTotal.Text = "0"
        Me.txtbxSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtbxTax
        '
        Me.txtbxTax.Enabled = False
        Me.txtbxTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbxTax.ForeColor = System.Drawing.Color.Black
        Me.txtbxTax.Location = New System.Drawing.Point(103, 218)
        Me.txtbxTax.Name = "txtbxTax"
        Me.txtbxTax.Size = New System.Drawing.Size(96, 22)
        Me.txtbxTax.TabIndex = 29
        Me.txtbxTax.Text = "0"
        Me.txtbxTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtbxChange
        '
        Me.txtbxChange.Enabled = False
        Me.txtbxChange.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbxChange.ForeColor = System.Drawing.Color.Black
        Me.txtbxChange.Location = New System.Drawing.Point(103, 187)
        Me.txtbxChange.Name = "txtbxChange"
        Me.txtbxChange.Size = New System.Drawing.Size(96, 22)
        Me.txtbxChange.TabIndex = 28
        Me.txtbxChange.Text = "0"
        Me.txtbxChange.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(30, 255)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(67, 15)
        Me.Label10.TabIndex = 27
        Me.Label10.Text = "Sub Total  : "
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(30, 220)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(34, 15)
        Me.Label9.TabIndex = 26
        Me.Label9.Text = "Tax : "
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Crimson
        Me.Label8.Location = New System.Drawing.Point(533, 513)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(69, 24)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "Total :"
        '
        'txtbxTotal
        '
        Me.txtbxTotal.Enabled = False
        Me.txtbxTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbxTotal.ForeColor = System.Drawing.Color.Black
        Me.txtbxTotal.Location = New System.Drawing.Point(610, 511)
        Me.txtbxTotal.Name = "txtbxTotal"
        Me.txtbxTotal.Size = New System.Drawing.Size(188, 29)
        Me.txtbxTotal.TabIndex = 24
        Me.txtbxTotal.Text = "0"
        Me.txtbxTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(55, 15)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(117, 16)
        Me.Label7.TabIndex = 22
        Me.Label7.Text = "Payment Method"
        '
        'txtbxPayment
        '
        Me.txtbxPayment.Enabled = False
        Me.txtbxPayment.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbxPayment.ForeColor = System.Drawing.Color.Black
        Me.txtbxPayment.Location = New System.Drawing.Point(44, 86)
        Me.txtbxPayment.Name = "txtbxPayment"
        Me.txtbxPayment.Size = New System.Drawing.Size(145, 22)
        Me.txtbxPayment.TabIndex = 20
        Me.txtbxPayment.Text = "0"
        Me.txtbxPayment.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'cmbPayment
        '
        Me.cmbPayment.Enabled = False
        Me.cmbPayment.FormattingEnabled = True
        Me.cmbPayment.Items.AddRange(New Object() {"Card"})
        Me.cmbPayment.Location = New System.Drawing.Point(44, 46)
        Me.cmbPayment.Name = "cmbPayment"
        Me.cmbPayment.Size = New System.Drawing.Size(145, 21)
        Me.cmbPayment.TabIndex = 19
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(30, 188)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 15)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "Change : "
        '
        'Panel6
        '
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel6.Controls.Add(Me.btnPay)
        Me.Panel6.Controls.Add(Me.Label7)
        Me.Panel6.Controls.Add(Me.cmbPayment)
        Me.Panel6.Controls.Add(Me.txtbxSubTotal)
        Me.Panel6.Controls.Add(Me.txtbxPayment)
        Me.Panel6.Controls.Add(Me.Label10)
        Me.Panel6.Controls.Add(Me.txtbxTax)
        Me.Panel6.Controls.Add(Me.txtbxChange)
        Me.Panel6.Controls.Add(Me.Label9)
        Me.Panel6.Controls.Add(Me.Label6)
        Me.Panel6.Location = New System.Drawing.Point(813, 410)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(229, 292)
        Me.Panel6.TabIndex = 6
        '
        'btnPay
        '
        Me.btnPay.BackColor = System.Drawing.Color.Transparent
        Me.btnPay.BackgroundImage = CType(resources.GetObject("btnPay.BackgroundImage"), System.Drawing.Image)
        Me.btnPay.ButtonText = "PAY"
        Me.btnPay.ButtonTextMarginLeft = 0
        Me.btnPay.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.btnPay.DisabledFillColor = System.Drawing.Color.Gray
        Me.btnPay.DisabledForecolor = System.Drawing.Color.Black
        Me.btnPay.ForeColor = System.Drawing.Color.White
        Me.btnPay.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnPay.IconPadding = 10
        Me.btnPay.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnPay.IdleBorderColor = System.Drawing.Color.White
        Me.btnPay.IdleBorderRadius = 25
        Me.btnPay.IdleBorderThickness = 0
        Me.btnPay.IdleFillColor = System.Drawing.Color.Crimson
        Me.btnPay.IdleIconLeftImage = Nothing
        Me.btnPay.IdleIconRightImage = Nothing
        Me.btnPay.Location = New System.Drawing.Point(33, 124)
        Me.btnPay.Name = "btnPay"
        StateProperties3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        StateProperties3.BorderRadius = 1
        StateProperties3.BorderThickness = 1
        StateProperties3.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        StateProperties3.IconLeftImage = Nothing
        StateProperties3.IconRightImage = Nothing
        Me.btnPay.onHoverState = StateProperties3
        Me.btnPay.Size = New System.Drawing.Size(165, 45)
        Me.btnPay.TabIndex = 34
        Me.btnPay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel4
        '
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.DataGridView1)
        Me.Panel4.Location = New System.Drawing.Point(28, 550)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(770, 152)
        Me.Panel4.TabIndex = 34
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowCustomTheming = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(196, Byte), Integer), CType(CType(206, Byte), Integer))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black
        Me.DataGridView1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.HighlightText
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.Crimson
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI Semibold", 11.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.ColumnHeadersHeight = 20
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column4, Me.Column1, Me.Column2, Me.Column3, Me.Delete})
        Me.DataGridView1.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(196, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.DataGridView1.CurrentTheme.AlternatingRowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.DataGridView1.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black
        Me.DataGridView1.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(114, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.DataGridView1.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.White
        Me.DataGridView1.CurrentTheme.BackColor = System.Drawing.Color.Crimson
        Me.DataGridView1.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(196, Byte), Integer))
        Me.DataGridView1.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.Crimson
        Me.DataGridView1.CurrentTheme.HeaderStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 11.75!, System.Drawing.FontStyle.Bold)
        Me.DataGridView1.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.DataGridView1.CurrentTheme.Name = Nothing
        Me.DataGridView1.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(216, Byte), Integer))
        Me.DataGridView1.CurrentTheme.RowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.DataGridView1.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.DataGridView1.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(114, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.DataGridView1.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(216, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(114, Byte), Integer), CType(CType(138, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView1.EnableHeadersVisualStyles = False
        Me.DataGridView1.GridColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(184, Byte), Integer), CType(CType(196, Byte), Integer))
        Me.DataGridView1.HeaderBackColor = System.Drawing.Color.Crimson
        Me.DataGridView1.HeaderBgColor = System.Drawing.Color.Empty
        Me.DataGridView1.HeaderForeColor = System.Drawing.Color.White
        Me.DataGridView1.Location = New System.Drawing.Point(3, 3)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowHeadersWidth = 15
        Me.DataGridView1.RowTemplate.Height = 40
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(762, 144)
        Me.DataGridView1.TabIndex = 0
        Me.DataGridView1.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Crimson
        '
        'Column4
        '
        Me.Column4.HeaderText = "productno."
        Me.Column4.Name = "Column4"
        Me.Column4.Visible = False
        '
        'Column1
        '
        Me.Column1.HeaderText = "Order"
        Me.Column1.Name = "Column1"
        '
        'Column2
        '
        Me.Column2.HeaderText = "Quantity"
        Me.Column2.Name = "Column2"
        '
        'Column3
        '
        Me.Column3.HeaderText = "Price"
        Me.Column3.Name = "Column3"
        '
        'Delete
        '
        Me.Delete.HeaderText = "Remove"
        Me.Delete.Name = "Delete"
        Me.Delete.Text = "Remove"
        Me.Delete.ToolTipText = "remove order"
        Me.Delete.UseColumnTextForButtonValue = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Candara", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(903, 309)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(49, 18)
        Me.Label14.TabIndex = 54
        Me.Label14.Text = "Admin"
        '
        'BunifuPictureBox4
        '
        Me.BunifuPictureBox4.AllowFocused = False
        Me.BunifuPictureBox4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.BunifuPictureBox4.BorderRadius = 91
        Me.BunifuPictureBox4.Image = Global.RestaurantOrderingSystem.My.Resources.Resources.chef_2309868_1943778
        Me.BunifuPictureBox4.IsCircle = True
        Me.BunifuPictureBox4.Location = New System.Drawing.Point(833, 111)
        Me.BunifuPictureBox4.Name = "BunifuPictureBox4"
        Me.BunifuPictureBox4.Size = New System.Drawing.Size(183, 183)
        Me.BunifuPictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.BunifuPictureBox4.TabIndex = 35
        Me.BunifuPictureBox4.TabStop = False
        Me.BunifuPictureBox4.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.Transparent
        Me.btnExit.BackgroundImage = CType(resources.GetObject("btnExit.BackgroundImage"), System.Drawing.Image)
        Me.btnExit.ButtonText = "Log Out"
        Me.btnExit.ButtonTextMarginLeft = 0
        Me.btnExit.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.btnExit.DisabledFillColor = System.Drawing.Color.Gray
        Me.btnExit.DisabledForecolor = System.Drawing.Color.White
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnExit.IconPadding = 10
        Me.btnExit.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnExit.IdleBorderColor = System.Drawing.Color.White
        Me.btnExit.IdleBorderRadius = 25
        Me.btnExit.IdleBorderThickness = 0
        Me.btnExit.IdleFillColor = System.Drawing.Color.Crimson
        Me.btnExit.IdleIconLeftImage = Nothing
        Me.btnExit.IdleIconRightImage = Nothing
        Me.btnExit.Location = New System.Drawing.Point(867, 333)
        Me.btnExit.Name = "btnExit"
        StateProperties1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        StateProperties1.BorderRadius = 1
        StateProperties1.BorderThickness = 1
        StateProperties1.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        StateProperties1.IconLeftImage = Nothing
        StateProperties1.IconRightImage = Nothing
        Me.btnExit.onHoverState = StateProperties1
        Me.btnExit.Size = New System.Drawing.Size(120, 24)
        Me.btnExit.TabIndex = 33
        Me.btnExit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnCalculate
        '
        Me.btnCalculate.BackColor = System.Drawing.Color.Transparent
        Me.btnCalculate.BackgroundImage = CType(resources.GetObject("btnCalculate.BackgroundImage"), System.Drawing.Image)
        Me.btnCalculate.ButtonText = "ADD TO CART"
        Me.btnCalculate.ButtonTextMarginLeft = 0
        Me.btnCalculate.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.btnCalculate.DisabledFillColor = System.Drawing.Color.Gray
        Me.btnCalculate.DisabledForecolor = System.Drawing.Color.White
        Me.btnCalculate.ForeColor = System.Drawing.Color.White
        Me.btnCalculate.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnCalculate.IconPadding = 10
        Me.btnCalculate.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnCalculate.IdleBorderColor = System.Drawing.Color.White
        Me.btnCalculate.IdleBorderRadius = 25
        Me.btnCalculate.IdleBorderThickness = 0
        Me.btnCalculate.IdleFillColor = System.Drawing.Color.Crimson
        Me.btnCalculate.IdleIconLeftImage = Nothing
        Me.btnCalculate.IdleIconRightImage = Nothing
        Me.btnCalculate.Location = New System.Drawing.Point(28, 502)
        Me.btnCalculate.Name = "btnCalculate"
        StateProperties2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        StateProperties2.BorderRadius = 1
        StateProperties2.BorderThickness = 1
        StateProperties2.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        StateProperties2.IconLeftImage = Nothing
        StateProperties2.IconRightImage = Nothing
        Me.btnCalculate.onHoverState = StateProperties2
        Me.btnCalculate.Size = New System.Drawing.Size(439, 40)
        Me.btnCalculate.TabIndex = 23
        Me.btnCalculate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Quantity
        '
        Me.Quantity.Enabled = False
        Me.Quantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Quantity.ForeColor = System.Drawing.Color.Black
        Me.Quantity.Location = New System.Drawing.Point(0, 550)
        Me.Quantity.Name = "Quantity"
        Me.Quantity.Size = New System.Drawing.Size(27, 29)
        Me.Quantity.TabIndex = 55
        Me.Quantity.Text = "0"
        Me.Quantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Quantity.Visible = False
        '
        'product
        '
        Me.product.Enabled = False
        Me.product.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.product.ForeColor = System.Drawing.Color.Black
        Me.product.Location = New System.Drawing.Point(0, 585)
        Me.product.Name = "product"
        Me.product.Size = New System.Drawing.Size(27, 29)
        Me.product.TabIndex = 56
        Me.product.Text = "0"
        Me.product.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.product.Visible = False
        '
        'MainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1068, 714)
        Me.Controls.Add(Me.product)
        Me.Controls.Add(Me.Quantity)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.BunifuPictureBox4)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.txtbxTotal)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "MainMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.BunifuPictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.BunifuPictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.BunifuPictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BunifuPictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents BunifuLabel1 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents chckbxCheesyBurgerDeluxe As System.Windows.Forms.CheckBox
    Friend WithEvents chckbxGarlicShrimp As System.Windows.Forms.CheckBox
    Friend WithEvents chckbxHawaiian As System.Windows.Forms.CheckBox
    Friend WithEvents chckbxPepperoni As System.Windows.Forms.CheckBox
    Friend WithEvents chckbxMargherita As System.Windows.Forms.CheckBox
    Friend WithEvents chckbxTomato As System.Windows.Forms.CheckBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents chckbxBolognese As System.Windows.Forms.CheckBox
    Friend WithEvents chckbxAlleVongole As System.Windows.Forms.CheckBox
    Friend WithEvents chckbxAglioOlio As System.Windows.Forms.CheckBox
    Friend WithEvents chckbxCarbonara As System.Windows.Forms.CheckBox
    Friend WithEvents txtbxMargherita As System.Windows.Forms.TextBox
    Friend WithEvents txtbxBolognese As System.Windows.Forms.TextBox
    Friend WithEvents txtbxAlleVongole As System.Windows.Forms.TextBox
    Friend WithEvents txtbxAglioOlio As System.Windows.Forms.TextBox
    Friend WithEvents txtbxCarbonara As System.Windows.Forms.TextBox
    Friend WithEvents txtbxTomato As System.Windows.Forms.TextBox
    Friend WithEvents txtbxCheesyBurgerDeluxe As System.Windows.Forms.TextBox
    Friend WithEvents txtbxGarlicShrimp As System.Windows.Forms.TextBox
    Friend WithEvents txtbxHawaiian As System.Windows.Forms.TextBox
    Friend WithEvents txtbxPepperoni As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtbxTotal As System.Windows.Forms.TextBox
    Friend WithEvents btnCalculate As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtbxPayment As System.Windows.Forms.TextBox
    Friend WithEvents cmbPayment As System.Windows.Forms.ComboBox
    Friend WithEvents btnExit As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents txtbxSubTotal As System.Windows.Forms.TextBox
    Friend WithEvents txtbxTax As System.Windows.Forms.TextBox
    Friend WithEvents txtbxChange As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents btnPay As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents BunifuPictureBox1 As Bunifu.UI.WinForms.BunifuPictureBox
    Friend WithEvents BunifuPictureBox2 As Bunifu.UI.WinForms.BunifuPictureBox
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents lblMargherita As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblBolognese As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblAlle As System.Windows.Forms.TextBox
    Friend WithEvents lblAglio As System.Windows.Forms.TextBox
    Friend WithEvents lblCarbonara As System.Windows.Forms.TextBox
    Friend WithEvents lblTomato As System.Windows.Forms.TextBox
    Friend WithEvents lblCheesyBurgerDeluxe As System.Windows.Forms.TextBox
    Friend WithEvents lblGarlicShrimp As System.Windows.Forms.TextBox
    Friend WithEvents lblHawaiian As System.Windows.Forms.TextBox
    Friend WithEvents lblPepperoni As System.Windows.Forms.TextBox
    Friend WithEvents lblS10 As System.Windows.Forms.Label
    Friend WithEvents lblS9 As System.Windows.Forms.Label
    Friend WithEvents lblS7 As System.Windows.Forms.Label
    Friend WithEvents lblS6 As System.Windows.Forms.Label
    Friend WithEvents lblS8 As System.Windows.Forms.Label
    Friend WithEvents lblS5 As System.Windows.Forms.Label
    Friend WithEvents lblS4 As System.Windows.Forms.Label
    Friend WithEvents lblS3 As System.Windows.Forms.Label
    Friend WithEvents lblS2 As System.Windows.Forms.Label
    Friend WithEvents lblS1 As System.Windows.Forms.Label
    Friend WithEvents BunifuPictureBox3 As Bunifu.UI.WinForms.BunifuPictureBox
    Friend WithEvents BunifuPictureBox4 As Bunifu.UI.WinForms.BunifuPictureBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As Bunifu.UI.WinForms.BunifuDataGridView
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Delete As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Quantity As System.Windows.Forms.TextBox
    Friend WithEvents product As System.Windows.Forms.TextBox

End Class
