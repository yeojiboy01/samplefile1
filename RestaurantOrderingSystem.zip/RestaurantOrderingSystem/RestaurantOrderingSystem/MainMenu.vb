﻿Public Class MainMenu
    Dim dt As New DataTable("Table")
    Dim index As Integer

    Private Sub chckbxHawaiian_CheckStateChanged(sender As Object, e As EventArgs) Handles chckbxHawaiian.CheckStateChanged
        txtbxHawaiian.Enabled = True
        txtbxHawaiian.Text = ""
        txtbxHawaiian.Focus()
        If chckbxHawaiian.Checked = False Then
            txtbxHawaiian.Text = "0"
            txtbxHawaiian.Enabled = False
        End If
    End Sub

    Private Sub chckbxMargherita_CheckedChanged(sender As Object, e As EventArgs) Handles chckbxMargherita.CheckedChanged
        txtbxMargherita.Enabled = True
        txtbxMargherita.Text = ""
        txtbxMargherita.Focus()
        If chckbxMargherita.Checked = False Then
            txtbxMargherita.Enabled = False
            txtbxMargherita.Text = "0"
        End If
    End Sub

    Private Sub chckbxPepperoni_CheckedChanged(sender As Object, e As EventArgs) Handles chckbxPepperoni.CheckedChanged
        txtbxPepperoni.Enabled = True
        txtbxPepperoni.Text = ""
        txtbxPepperoni.Focus()
        If chckbxPepperoni.Checked = False Then
            txtbxPepperoni.Text = "0"
            txtbxPepperoni.Enabled = False
        End If
    End Sub

    Private Sub chckbxGarlicShrimp_CheckedChanged(sender As Object, e As EventArgs) Handles chckbxGarlicShrimp.CheckedChanged
        txtbxGarlicShrimp.Enabled = True
        txtbxGarlicShrimp.Text = ""
        txtbxGarlicShrimp.Focus()
        If chckbxGarlicShrimp.Checked = False Then
            txtbxGarlicShrimp.Text = "0"
            txtbxGarlicShrimp.Enabled = False
        End If
    End Sub

    Private Sub chckbxCheesyBurgerDeluxe_CheckedChanged(sender As Object, e As EventArgs) Handles chckbxCheesyBurgerDeluxe.CheckedChanged
        txtbxCheesyBurgerDeluxe.Enabled = True
        txtbxCheesyBurgerDeluxe.Text = ""
        txtbxCheesyBurgerDeluxe.Focus()
        If chckbxCheesyBurgerDeluxe.Checked = False Then
            txtbxCheesyBurgerDeluxe.Text = "0"
            txtbxCheesyBurgerDeluxe.Enabled = False
        End If
    End Sub


    Private Sub chckbxTomato_CheckedChanged(sender As Object, e As EventArgs) Handles chckbxTomato.CheckedChanged
        txtbxTomato.Enabled = True
        txtbxTomato.Text = ""
        txtbxTomato.Focus()
        If chckbxTomato.Checked = False Then
            txtbxTomato.Text = "0"
            txtbxTomato.Enabled = False
        End If
    End Sub

    Private Sub chckbxCarbonara_CheckedChanged(sender As Object, e As EventArgs) Handles chckbxCarbonara.CheckedChanged
        txtbxCarbonara.Enabled = True
        txtbxCarbonara.Text = ""
        txtbxCarbonara.Focus()
        If chckbxCarbonara.Checked = False Then
            txtbxCarbonara.Text = "0"
            txtbxCarbonara.Enabled = False
        End If
    End Sub

    Private Sub chckbxAglioOlio_CheckedChanged(sender As Object, e As EventArgs) Handles chckbxAglioOlio.CheckedChanged
        txtbxAglioOlio.Enabled = True
        txtbxAglioOlio.Text = ""
        txtbxAglioOlio.Focus()
        If chckbxAglioOlio.Checked = False Then
            txtbxAglioOlio.Text = "0"
            txtbxAglioOlio.Enabled = False
        End If
    End Sub

    Private Sub chckbxAlleVongole_CheckedChanged(sender As Object, e As EventArgs) Handles chckbxAlleVongole.CheckedChanged
        txtbxAlleVongole.Enabled = True
        txtbxAlleVongole.Text = ""
        txtbxAlleVongole.Focus()
        If chckbxAlleVongole.Checked = False Then
            txtbxAlleVongole.Text = "0"
            txtbxAlleVongole.Enabled = False
        End If
    End Sub

    Private Sub chckbxBolognese_CheckedChanged(sender As Object, e As EventArgs) Handles chckbxBolognese.CheckedChanged
        txtbxBolognese.Enabled = True
        txtbxBolognese.Text = ""
        txtbxBolognese.Focus()
        If chckbxBolognese.Checked = False Then
            txtbxBolognese.Text = "0"
            txtbxBolognese.Enabled = False
        End If
    End Sub

    Private Sub btnPay_Click(sender As Object, e As EventArgs) Handles btnPay.Click
        Dim FIRSTNUMBER, tax, SECONDNUMBER, change, taxx As Single

        FIRSTNUMBER = Val(txtbxTotal.Text)
        SECONDNUMBER = Val(txtbxPayment.Text)
        tax = FIRSTNUMBER * 0.04
        taxx = FIRSTNUMBER - tax

        change = SECONDNUMBER - (FIRSTNUMBER)

        If SECONDNUMBER < FIRSTNUMBER Then
            MsgBox("INVALID PAYMENT", MsgBoxStyle.Exclamation, "ERROR")
            txtbxPayment.Focus()
        Else
            txtbxSubTotal.Text = taxx
            txtbxChange.Text = change
            txtbxTax.Text = tax
        End If
    End Sub

    Private Sub MainMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim row As DataGridViewRow = Me.DataGridView1.RowTemplate
        row.Height = 35
        row.MinimumHeight = 20
        cmbPayment.Items.Add("Cash In")
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs)
        If MsgBox("Are you sure you want reset all the data?", MsgBoxStyle.YesNo, "EXIT") = Microsoft.VisualBasic.MsgBoxResult.Yes Then
            chckbxBolognese.Checked = False
            For Each txt In {txtbxAglioOlio, txtbxAlleVongole, txtbxBolognese, txtbxCarbonara, txtbxChange, txtbxCheesyBurgerDeluxe, txtbxGarlicShrimp, txtbxHawaiian, txtbxMargherita, txtbxPayment, txtbxPepperoni, txtbxSubTotal, txtbxTax, txtbxTomato, txtbxTotal}
                txt.Text = "0"
                txt.Enabled = False
            Next
            For Each chck In {chckbxAglioOlio, chckbxAlleVongole, chckbxBolognese, chckbxCarbonara, chckbxCheesyBurgerDeluxe, chckbxGarlicShrimp, chckbxHawaiian, chckbxMargherita, chckbxPepperoni, chckbxTomato}
                chck.Checked = False
            Next
            cmbPayment.Enabled = False
            cmbPayment.Items.Clear()
            btnPay.Enabled = False
        End If
    End Sub
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        If MsgBox("Are you sure you want to LogOut?", MsgBoxStyle.OkCancel, "EXIT") = Microsoft.VisualBasic.MsgBoxResult.Ok Then
            LogIn.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub Numbers_only(sender As Object, e As KeyPressEventArgs) Handles txtbxTomato.KeyPress, txtbxPepperoni.KeyPress, txtbxPayment.KeyPress, txtbxAlleVongole.KeyPress, txtbxGarlicShrimp.KeyPress, txtbxHawaiian.KeyPress, txtbxMargherita.KeyPress, txtbxCarbonara.KeyPress, txtbxAglioOlio.KeyPress, txtbxCheesyBurgerDeluxe.KeyPress, txtbxBolognese.KeyPress
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Then
        Else
            e.Handled = True
            MsgBox("Invalid Input", MsgBoxStyle.Exclamation, "ERROR")
        End If
    End Sub

    Private Sub txtbxPayment_Enter(sender As Object, e As EventArgs) Handles txtbxPayment.Enter
        txtbxPayment.Text = " "

    End Sub

    Private Sub txtbxPayment_Leave(sender As Object, e As EventArgs) Handles txtbxPayment.Leave
        If txtbxPayment.Enabled = True Then
            If txtbxPayment.Text = "0" Then
                MsgBox("Invalid input", MsgBoxStyle.Exclamation, "ERROR")
                txtbxPayment.Focus()
            ElseIf txtbxPayment.Text = "" Then
                MsgBox("Please input quantity", MsgBoxStyle.Exclamation, "ERROR")
                txtbxPayment.Focus()
            End If
        End If
    End Sub

    Private Sub cmbPayment_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbPayment.SelectedIndexChanged

        If cmbPayment.SelectedItem = "Cash In" Then
            txtbxPayment.Enabled = True
            txtbxPayment.Focus()
            btnPay.Enabled = True
        End If
    End Sub
    Private Sub txtbxMargherita_Leave(sender As Object, e As EventArgs) Handles txtbxMargherita.Leave
        If txtbxMargherita.Enabled = True Then
            If txtbxMargherita.Text = "0" Then
                MsgBox("Invalid input", MsgBoxStyle.Exclamation, "ERROR")
                txtbxMargherita.Focus()
            ElseIf txtbxMargherita.Text = "" Then
                MsgBox("Please input quantity", MsgBoxStyle.Exclamation, "ERROR")
                txtbxMargherita.Focus()
            End If
        End If
    End Sub

    Private Sub txtbxPepperoni_Leave(sender As Object, e As EventArgs) Handles txtbxPepperoni.Leave
        If txtbxPepperoni.Enabled = True Then
            If txtbxPepperoni.Text = "0" Then
                MsgBox("Invalid input", MsgBoxStyle.Exclamation, "ERROR")
                txtbxPepperoni.Focus()
            ElseIf txtbxPepperoni.Text = "" Then
                MsgBox("Please input quantity", MsgBoxStyle.Exclamation, "ERROR")
                txtbxPepperoni.Focus()
            End If
        End If
    End Sub

    Private Sub txtbxHawaiian_Leave(sender As Object, e As EventArgs) Handles txtbxHawaiian.Leave
        If txtbxHawaiian.Enabled = True Then
            If txtbxHawaiian.Text = "0" Then
                MsgBox("Invalid input", MsgBoxStyle.Exclamation, "ERROR")
                txtbxHawaiian.Focus()
            ElseIf txtbxHawaiian.Text = "" Then
                MsgBox("Please input quantity", MsgBoxStyle.Exclamation, "ERROR")
                txtbxHawaiian.Focus()
            End If
        End If
    End Sub

    Private Sub txtbxGarlicShrimp_Leave(sender As Object, e As EventArgs) Handles txtbxGarlicShrimp.Leave
        If txtbxGarlicShrimp.Enabled = True Then
            If txtbxGarlicShrimp.Text = "0" Then
                MsgBox("Invalid input", MsgBoxStyle.Exclamation, "ERROR")
                txtbxGarlicShrimp.Focus()
            ElseIf txtbxGarlicShrimp.Text = "" Then
                MsgBox("Please input quantity", MsgBoxStyle.Exclamation, "ERROR")
                txtbxGarlicShrimp.Focus()
            End If
        End If
    End Sub

    Private Sub txtbxCheesyBurgerDeluxe_Leave(sender As Object, e As EventArgs) Handles txtbxCheesyBurgerDeluxe.Leave
        If txtbxCheesyBurgerDeluxe.Enabled = True Then
            If txtbxCheesyBurgerDeluxe.Text = "0" Then
                MsgBox("Invalid input", MsgBoxStyle.Exclamation, "ERROR")
                txtbxCheesyBurgerDeluxe.Focus()
            ElseIf txtbxCheesyBurgerDeluxe.Text = "" Then
                MsgBox("Please input quantity", MsgBoxStyle.Exclamation, "ERROR")
                txtbxCheesyBurgerDeluxe.Focus()
            End If
        End If
    End Sub

    Private Sub txtbxTomato_Leave(sender As Object, e As EventArgs) Handles txtbxTomato.Leave
        If txtbxTomato.Enabled = True Then
            If txtbxTomato.Text = "0" Then
                MsgBox("Invalid input", MsgBoxStyle.Exclamation, "ERROR")
                txtbxTomato.Focus()
            ElseIf txtbxTomato.Text = "" Then
                MsgBox("Please input quantity", MsgBoxStyle.Exclamation, "ERROR")
                txtbxTomato.Focus()
            End If
        End If
    End Sub

    Private Sub txtbxCarbonara_Leave(sender As Object, e As EventArgs) Handles txtbxCarbonara.Leave
        If txtbxCarbonara.Enabled = True Then
            If txtbxCarbonara.Text = "0" Then
                MsgBox("Invalid input", MsgBoxStyle.Exclamation, "ERROR")
                txtbxCarbonara.Focus()
            ElseIf txtbxCarbonara.Text = "" Then
                MsgBox("Please input quantity", MsgBoxStyle.Exclamation, "ERROR")
                txtbxCarbonara.Focus()
            End If
        End If
    End Sub

    Private Sub txtbxAglioOlio_Leave(sender As Object, e As EventArgs) Handles txtbxAglioOlio.Leave
        If txtbxAglioOlio.Enabled = True Then
            If txtbxAglioOlio.Text = "0" Then
                MsgBox("Invalid input", MsgBoxStyle.Exclamation, "ERROR")
                txtbxAglioOlio.Focus()
            ElseIf txtbxAglioOlio.Text = "" Then
                MsgBox("Please input quantity", MsgBoxStyle.Exclamation, "ERROR")
                txtbxAglioOlio.Focus()
            End If
        End If
    End Sub

    Private Sub txtbxAlleVongole_Leave(sender As Object, e As EventArgs) Handles txtbxAlleVongole.Leave
        If txtbxAlleVongole.Enabled = True Then
            If txtbxAlleVongole.Text = "0" Then
                MsgBox("Invalid input", MsgBoxStyle.Exclamation, "ERROR")
                txtbxAlleVongole.Focus()
            ElseIf txtbxAlleVongole.Text = "" Then
                MsgBox("Please input quantity", MsgBoxStyle.Exclamation, "ERROR")
                txtbxAlleVongole.Focus()
            End If
        End If
    End Sub

    Private Sub txtbxBolognese_Leave(sender As Object, e As EventArgs) Handles txtbxBolognese.Leave
        If txtbxBolognese.Enabled = True Then
            If txtbxBolognese.Text = "0" Then
                MsgBox("Invalid input", MsgBoxStyle.Exclamation, "ERROR")
                txtbxBolognese.Focus()
            ElseIf txtbxBolognese.Text = "" Then
                MsgBox("Please input quantity", MsgBoxStyle.Exclamation, "ERROR")
                txtbxBolognese.Focus()
            End If
        End If
    End Sub

    Private Sub lblMargherita_TextChanged(sender As Object, e As EventArgs) Handles lblMargherita.TextChanged
        Dim A As Integer
        A = lblMargherita.Text

        If A <= 5 And A >= 3 Then
            lblMargherita.BackColor = Color.Yellow
        ElseIf A >= 1 And A < 3 Then
            lblMargherita.BackColor = Color.Crimson
        ElseIf A = 0 Then
            lblS1.BringToFront()
            chckbxMargherita.Enabled = False
            lblMargherita.BackColor = Color.Crimson
        End If
    End Sub

    Private Sub lblPepperoni_TextChanged(sender As Object, e As EventArgs) Handles lblPepperoni.TextChanged
        Dim A As Integer
        A = lblPepperoni.Text

        If A <= 5 And A >= 3 Then
            lblPepperoni.BackColor = Color.Yellow
        ElseIf A >= 1 And A < 3 Then
            lblPepperoni.BackColor = Color.Crimson
        ElseIf A = 0 Then
            lblS2.BringToFront()
            chckbxPepperoni.Enabled = False
            lblPepperoni.BackColor = Color.Crimson
        End If
    End Sub

    Private Sub lblHawaiian_TextChanged(sender As Object, e As EventArgs) Handles lblHawaiian.TextChanged
        Dim A As Integer
        A = lblHawaiian.Text

        If A <= 5 And A >= 3 Then
            lblHawaiian.BackColor = Color.Yellow
        ElseIf A >= 1 And A < 3 Then
            lblHawaiian.BackColor = Color.Crimson
        ElseIf A = 0 Then
            lblS3.BringToFront()
            chckbxHawaiian.Enabled = False
            lblHawaiian.BackColor = Color.Crimson
        End If
    End Sub

    Private Sub lblGarlicShrimp_TextChanged(sender As Object, e As EventArgs) Handles lblGarlicShrimp.TextChanged
        Dim A As Integer
        A = lblGarlicShrimp.Text

        If A <= 5 And A >= 3 Then
            lblGarlicShrimp.BackColor = Color.Yellow
        ElseIf A >= 1 And A < 3 Then
            lblGarlicShrimp.BackColor = Color.Crimson
        ElseIf A = 0 Then
            lblS4.BringToFront()
            chckbxGarlicShrimp.Enabled = False
            lblGarlicShrimp.BackColor = Color.Crimson
        End If
    End Sub

    Private Sub lblCheesyBurgerDeluxe_TextChanged(sender As Object, e As EventArgs) Handles lblCheesyBurgerDeluxe.TextChanged
        Dim A As Integer
        A = lblCheesyBurgerDeluxe.Text

        If A <= 5 And A >= 3 Then
            lblCheesyBurgerDeluxe.BackColor = Color.Yellow
        ElseIf A >= 1 And A < 3 Then
            lblCheesyBurgerDeluxe.BackColor = Color.Crimson
        ElseIf A = 0 Then
            lblS5.BringToFront()
            chckbxCheesyBurgerDeluxe.Enabled = False
            lblCheesyBurgerDeluxe.BackColor = Color.Crimson
        End If
    End Sub

    Private Sub lblTomato_TextChanged(sender As Object, e As EventArgs) Handles lblTomato.TextChanged
        Dim A As Integer
        A = lblTomato.Text

        If A <= 5 And A >= 3 Then
            lblTomato.BackColor = Color.Yellow
        ElseIf A >= 1 And A < 3 Then
            lblTomato.BackColor = Color.Crimson
        ElseIf A = 0 Then
            lblS6.BringToFront()
            chckbxTomato.Enabled = False
            lblTomato.BackColor = Color.Crimson
        End If
    End Sub

    Private Sub lblCarbonara_TextChanged(sender As Object, e As EventArgs) Handles lblCarbonara.TextChanged
        Dim A As Integer
        A = lblCarbonara.Text

        If A <= 5 And A >= 3 Then
            lblCarbonara.BackColor = Color.Yellow
        ElseIf A >= 1 And A < 3 Then
            lblCarbonara.BackColor = Color.Crimson
        ElseIf A = 0 Then
            lblS7.BringToFront()
            chckbxCarbonara.Enabled = False
            lblCarbonara.BackColor = Color.Crimson
        End If
    End Sub

    Private Sub lblAglio_TextChanged(sender As Object, e As EventArgs) Handles lblAglio.TextChanged
        Dim A As Integer
        A = lblAglio.Text

        If A <= 5 And A >= 3 Then
            lblAglio.BackColor = Color.Yellow
        ElseIf A >= 1 And A < 3 Then
            lblAglio.BackColor = Color.Crimson
        ElseIf A = 0 Then
            lblS8.BringToFront()
            chckbxAglioOlio.Enabled = False
            lblAglio.BackColor = Color.Crimson
        End If
    End Sub

    Private Sub lblAlle_TextChanged(sender As Object, e As EventArgs) Handles lblAlle.TextChanged
        Dim A As Integer
        A = lblAlle.Text

        If A <= 5 And A >= 3 Then
            lblAlle.BackColor = Color.Yellow
        ElseIf A >= 1 And A < 3 Then
            lblAlle.BackColor = Color.Crimson
        ElseIf A = 0 Then
            lblS9.BringToFront()
            chckbxAlleVongole.Enabled = False
            lblAlle.BackColor = Color.Crimson
        End If
    End Sub

    Private Sub lblBolognese_TextChanged(sender As Object, e As EventArgs) Handles lblBolognese.TextChanged
        Dim A As Integer
        A = lblBolognese.Text

        If A <= 5 And A >= 3 Then
            lblBolognese.BackColor = Color.Yellow
        ElseIf A >= 1 And A < 3 Then
            lblBolognese.BackColor = Color.Crimson
        ElseIf A = 0 Then
            lblS10.BringToFront()
            chckbxBolognese.Enabled = False
            lblBolognese.BackColor = Color.Crimson
        End If
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        Dim MARGHERITA, PEPPERONI, HAWAIIAN, GARLICSHRIMP, CHEESYBURGER, TOMATO, CARBONARA, AGLIO, ALLE, BOLOGNESE As Integer
        Dim M, P, H, G, C, T, CA, AG, AL, B As Integer
        Dim TM, TP, TH, TG, TC, TT, TCA, TAG, TAL, TB As Integer

        'STOCKS
        M = lblMargherita.Text
        P = lblPepperoni.Text
        H = lblHawaiian.Text
        G = lblGarlicShrimp.Text
        C = lblCheesyBurgerDeluxe.Text
        T = lblTomato.Text
        CA = lblCarbonara.Text
        AG = lblAglio.Text
        AL = lblAlle.Text
        B = lblBolognese.Text

        'QUANTITY
        MARGHERITA = txtbxMargherita.Text
        PEPPERONI = txtbxPepperoni.Text
        HAWAIIAN = txtbxHawaiian.Text
        GARLICSHRIMP = txtbxGarlicShrimp.Text
        CHEESYBURGER = txtbxCheesyBurgerDeluxe.Text
        TOMATO = txtbxTomato.Text
        CARBONARA = txtbxCarbonara.Text
        AGLIO = txtbxAglioOlio.Text
        ALLE = txtbxAlleVongole.Text
        BOLOGNESE = txtbxBolognese.Text

        lblCheesyBurgerDeluxe.Text = C - CHEESYBURGER
        lblMargherita.Text = M - MARGHERITA
        lblGarlicShrimp.Text = G - GARLICSHRIMP
        lblHawaiian.Text = H - HAWAIIAN
        lblPepperoni.Text = P - PEPPERONI
        lblAglio.Text = AG - AGLIO
        lblAlle.Text = AL - ALLE
        lblBolognese.Text = B - BOLOGNESE
        lblCarbonara.Text = C - CARBONARA
        lblTomato.Text = T - TOMATO

        TM = MARGHERITA * 699
        TP = PEPPERONI * 699
        TH = HAWAIIAN * 699
        TG = GARLICSHRIMP * 699
        TC = CHEESYBURGER * 699
        TT = TOMATO * 210
        TAL = ALLE * 220
        TAG = AGLIO * 230
        TCA = CARBONARA * 235
        TB = BOLOGNESE * 240

        ' txtbxTotal.Text = TM + TP + TH + TG + TC + TCA + TT + TAL + TAG + TB
        If chckbxAglioOlio.Checked = True Then
            DataGridView1.Rows.Add(8, chckbxAglioOlio.Text, txtbxAglioOlio.Text, TAG)
        End If
        If chckbxAlleVongole.Checked = True Then
            DataGridView1.Rows.Add(9, chckbxAlleVongole.Text, txtbxAlleVongole.Text, TAL)
        End If
        If chckbxBolognese.Checked = True Then
            DataGridView1.Rows.Add(10, chckbxBolognese.Text, txtbxBolognese.Text, TB)
        End If
        If chckbxCarbonara.Checked = True Then
            DataGridView1.Rows.Add(7, chckbxCarbonara.Text, txtbxCarbonara.Text, TCA)
        End If
        If chckbxCheesyBurgerDeluxe.Checked = True Then
            DataGridView1.Rows.Add(5, chckbxCheesyBurgerDeluxe.Text, txtbxCheesyBurgerDeluxe.Text, TC)
        End If
        If chckbxGarlicShrimp.Checked = True Then
            DataGridView1.Rows.Add(4, chckbxGarlicShrimp.Text, txtbxGarlicShrimp.Text, TG)
        End If
        If chckbxHawaiian.Checked = True Then
            DataGridView1.Rows.Add(3, chckbxHawaiian.Text, txtbxHawaiian.Text, TH)
        End If
        If chckbxMargherita.Checked = True Then
            DataGridView1.Rows.Add(1, chckbxMargherita.Text, txtbxMargherita.Text, TM)
        End If
        If chckbxPepperoni.Checked = True Then
            DataGridView1.Rows.Add(2, chckbxPepperoni.Text, txtbxPepperoni.Text, TP)
        End If
        If chckbxTomato.Checked = True Then
            DataGridView1.Rows.Add(6, chckbxTomato.Text, txtbxTomato.Text, TT)
        End If

        Dim amount As Integer

        For index As Integer = 0 To DataGridView1.RowCount - 1
            amount += Convert.ToInt32(DataGridView1.Rows(index).Cells(3).Value)

            'if you have the other column to get the result you  could add a new one like these above (just change Cells(2) to the one you added)
        Next
        txtbxTotal.Text = amount
        For Each txt In {txtbxAglioOlio, txtbxAlleVongole, txtbxBolognese, txtbxCarbonara, txtbxChange, txtbxCheesyBurgerDeluxe, txtbxGarlicShrimp, txtbxHawaiian, txtbxMargherita, txtbxPepperoni, txtbxTomato}
            txt.Text = "0"
            txt.Enabled = False
        Next
        For Each chck In {chckbxAglioOlio, chckbxAlleVongole, chckbxBolognese, chckbxCarbonara, chckbxCheesyBurgerDeluxe, chckbxGarlicShrimp, chckbxHawaiian, chckbxMargherita, chckbxPepperoni, chckbxTomato}
            chck.Checked = False
        Next

        If txtbxTotal.Text.Length > 0 Then
            cmbPayment.Enabled = True
        End If

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim amount, sana As Integer

        sana = e.RowIndex

        Dim selectedRow As DataGridViewRow
        selectedRow = DataGridView1.Rows(sana)

        If e.ColumnIndex = 4 Then
            Dim userMsg As String
            Dim testMsg, m, l, n As Integer
            userMsg = Microsoft.VisualBasic.InputBox("Input password to remove the order", "Remove Order", "Enter Password", 500, 700)
            If userMsg = "pidgey" Then

                testMsg = MsgBox("Succesful", vbOKCancel + vbInformation, "Order Removed.")

                Quantity.Text = selectedRow.Cells(2).Value.ToString()
                product.Text = selectedRow.Cells(0).Value.ToString()

                l = Quantity.Text
                n = product.Text

                If n = 1 Then
                    m = lblMargherita.Text
                    lblMargherita.Text = m + l
                End If
                If n = 2 Then
                    m = lblPepperoni.Text
                    lblPepperoni.Text = m + l
                End If
                If n = 3 Then
                    m = lblHawaiian.Text
                    lblHawaiian.Text = m + l
                End If
                If n = 4 Then
                    m = lblGarlicShrimp.Text
                    lblGarlicShrimp.Text = m + l
                End If
                If n = 5 Then
                    m = lblCheesyBurgerDeluxe.Text
                    lblCheesyBurgerDeluxe.Text = m + l
                End If
                If n = 6 Then
                    m = lblTomato.Text
                    lblTomato.Text = m + l
                End If
                If n = 7 Then
                    m = lblCarbonara.Text
                    lblCarbonara.Text = m + l
                End If
                If n = 8 Then
                    m = lblAglio.Text
                    lblAglio.Text = m + l
                End If
                If n = 9 Then
                    m = lblAlle.Text
                    lblAlle.Text = m + l
                End If
                If n = 10 Then
                    m = lblBolognese.Text
                    lblBolognese.Text = m + l
                End If

                DataGridView1.Rows.Remove(DataGridView1.SelectedRows(index))
                For indexus As Integer = 0 To DataGridView1.RowCount - 1
                    amount += Convert.ToInt32(DataGridView1.Rows(indexus).Cells(3).Value)
                Next
                txtbxTotal.Text = amount
            End If
        Else
            MessageBox.Show("Password Incorrect please try again.")
        End If
    End Sub
End Class
